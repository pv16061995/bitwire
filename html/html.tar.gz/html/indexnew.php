<?php 
@SESSION_START();
?>
<html>
<head>
    <style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}</style>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>BITWire - Wallet for Bitcoin and Bitcoin Cash</title>
        <meta name="description" content="Send, receive and securely store your Bitcoin and Bitcoin Cash. BITWIRE.com wallet is available on web, iOS and Android">

        <link rel="icon" href="img/favicon.png" type="image/x-icon" />
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="shortcut icon" href="wallet/v4-6-1/favicon.ico" type="image/x-icon">

        <link  href="wallet/v4-6-1/css/app.css" rel="stylesheet">
        <style>
            .owrcoin{
                padding: 15px 5px;
                border-radius: 50%;
                border: 1px solid #006552;
            }
            .margin-top-50{
                margin-top: 50px;
            }
@media (min-width:768px) {
    .bitwiremob {
         margin-top: 0px;
    }
}
 
@media (max-width:480px) {
    .bitwiremob {
         margin-top: 217px;
    }
}
 
 @media (max-width:320px) {
    .bitwiremob {
         margin-top: 217px;
    }
}
   @media (max-width:768px) {
    .bitwiremob {
         margin-top: 217px;
    }
}
             
        </style>

       
    </head>

    <body ng-class="getBodyClasses()" class="network-btc state-app state-app_setup state-app_setup_register">
        <!-- uiView:  -->
        <div class="bodyViewContainer ng-scope" ui-view="">
            <!-- uiView:  -->
            <div class="base-view ng-scope" ui-view="">
                <div class="ng-scope">
    <header class="top-header ng-isolate-scope" mode="'loggedout'">
    <div class="container">
        <div class="logo pull-left">
            <a ng-href="#" target="_self" href="#">
                <img src="wallet/v4-6-1/img/bitwire-final.png"></a>
        </div>

        <div class="pull-right">
            <!-- ngIf: mode == 'loggedout' --><ul class="nav navbar-nav ng-scope" ng-if="mode == 'loggedout'">

            <?php if(!isset($_SESSION['user_id'])){


                ?>
                <li ng-class="{'active':$state.is('app.setup.register')}" class="active">
                    <a ui-sref="app.setup.register" class="ng-binding" href="signupnew.php">Sign Up</a>
                </li>
                <li ng-class="{'active':$state.is('app.setup.login')}">
                    <a ui-sref="app.setup.login" class="ng-binding" href="loginnew.php">Sign In</a>
                </li>

                <?php }
                else 
                {?>
                    <div class="dropdown pull-right">
      <button class="btn btn-default" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" >
        <i class="fa fa-bars " aria-hidden="true"></i>
      </button>
      <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
         <li class="nav-item nav-dropdown">
             <a class="nav-link" href="index.php?curr=<?php echo base64_encode('inrw');?>"> FUNDS</a>
         </li>

         <li class="nav-item nav-dropdown">
             <a class="nav-link" href="setting.php">SETTING</a>
         </li>

         <li class="nav-item nav-dropdown">
             <a class="nav-link" href="contactus.php">CONTACT US</a>
         </li>
         <li>
           <a class="nav-item nav-dropdown" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
         </li>

       <li class="nav-item dropdown d-md-down-none">
           <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
               <i class="fa fa-user-circle" style="font-size: 20px;"></i>
           </a>
           <div class="dropdown-menu dropdown-menu-right">
           <a class="dropdown-item" href=""><i class="fa fa-user" aria-hidden="true"></i> <?php echo $user_email; ?></a>
           <a class="dropdown-item" href="securitycenter.php"><i class="fa fa-lock" aria-hidden="true"></i> Security Center</a>
           <a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>

           </div>
       </li>
      </ul>
    </div>
               <?php  }



                ?>
            </ul><!-- end ngIf: mode == 'loggedout' -->

            <!-- ngIf: mode == 'loggedin' -->

            <!-- ngIf: mode == 'explorer' -->
        </div>
    </div>
</header>

   <!-- uiView:  --><div ui-view="" class="ng-scope"><div class="appWrapper landing-page">
    <div class="login-block">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="login-block-description text-center">
                        <h1 class="ng-binding">One Platform for all world currencies</h1>
                        <p class="ng-binding">Send, receive, and store your funds securely with bitwire wallet.</p>
                        
                    </div>
                </div>

                <div class="col-md-5">
                    <ng-transclude>
    
    <div class="smallButtons text-center ng-scope">
        <a class="sentence-case ng-binding" ui-sref="app.setup.login" href="#/setup/login"></a><br>
    </div>
</ng-transclude>
                </div>
            </div>
        </div>
    </div>

    <div class="login-block login-block-highlighted">
        <div class="container">
            <div class="row">
               
                <div class="col-sm-12 text-center col-xs-12">
                    <div class="block-content">
                        <h2 class="ng-binding">Stay In Control</h2>
                        <p class="ng-binding">Bitwire empowers you to send and receive payments without trust or permission from any third-party.</p>
                        <p class="ng-binding">Bitwire never has access to all cryptocurrencies equivalent to fiat, and giving you the security, privacy and power to own your wealth.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="login-block-parallax">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="block-content text-center">
                        <p class="ng-binding">Your Crypto. Your Control.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="login-block">
        <div class="container">
            <div class="row">
                <div class="col-sm-offset-2 col-sm-8">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="block-content text-center">
                                <h2 class="ng-binding">Benefits for Your Digital Life</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row iit-15">
                        <div class="col-sm-4 col-xs-12 text-center text-center">
                            <img class="login-icon" ng-src="wallet/v4-6-1/img/1.png" src="wallet/v4-6-1/img/1.png">
                            <p class="ng-binding">Send and receive wires easily and securely</p>
                        </div>
                        <div class="col-sm-4 col-xs-12 text-center text-center">
                            <img class="login-icon" ng-src="wallet/v4-6-1/img/2.png" src="wallet/v4-6-1/img/2.png">
                            <p class="ng-binding">Maintain full control over your wires private keys</p>
                        </div>
                        <div class="col-sm-4 col-xs-12 text-center text-center">
                            <img class="login-icon" ng-src="wallet/v4-6-1/img/3.png" src="wallet/v4-6-1/img/3.png">
                            <p class="ng-binding">Pay friends without QR codes or long addresses</p>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="block-content text-center">
                                <h2 class="ng-binding">The future of fiat currencies in digital way.</h2>
                                <em>The unique fiat-crypto currencies equivalent to their fiat.</em>
                            </div>
                        </div>
                    </div>
          

                    <div class="container">
                        <div class="row margin-top-50">

                         <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">INRW</span></div>
                         <div class="col-md-3 col-xs-3  text-center"><span class="owrcoin ">USDW</span></div>
                         <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">EURW</span></div>
                         <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">GBPW</span></div>
                     
                         </div>
                      <div class="row margin-top-50">
                        <div class="col-md-3 col-xs-3  text-center"><span class="owrcoin ">BRLW</span></div>
                      <div class="col-md-3 col-xs-3 text-center "><span class="owrcoin ">PLNW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">CADW</span></div>
                      <div class="col-md-3 col-xs-3  text-center"><span class="owrcoin ">TRYW</span></div>
                      </div>
                   <div class="row margin-top-50">
                     <div class="col-md-3 col-xs-3  text-center"><span class="owrcoin ">RUBW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">MXNW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">CZKW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">ILSW</span></div>
                     
                    </div>
                   <div class="row margin-top-50">
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">NZDW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">JPYW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">SEKW</span></div>
                      <div class="col-md-3 col-xs-3 text-center"><span class="owrcoin ">AUDW</span></div>
                     </div>
                    </div>  
                </div>
        </div><div class="login-block login-block-highlighted"  style="
    /* color: #fff; */
    background: #fff;
">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center bitwiremob">
                    <h2 class="ng-binding">Create your bitwire Wallet</h2>
                    <p>
                        <a ui-sref="app.setup.register" class="btn btn-primary btn-lg ng-binding" href="signupnew.php">Create a new wallet</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer" style="    display: block;
    height: 65px;padding: 0;    bottom: inherit;">
        <div class="container">
            <div class="row text-center" style="
                color: #fff;
            ">
                <h2>BITWIRE@2017</h2>
            </div>
        </div>
    </footer>
    </div>
</div>

 

</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>

       